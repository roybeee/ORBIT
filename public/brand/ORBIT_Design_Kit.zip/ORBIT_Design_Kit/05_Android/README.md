# Android 아이콘 적용

`res` 내용을 앱의 `app/src/main/res`에 병합합니다. AndroidManifest의 android:icon과 android:roundIcon이 @mipmap/ic_launcher를 가리키도록 연결합니다. 기존 리소스 이름 충돌을 확인하세요. Android 8+ 적응형 아이콘, Android 13+ 단색 테마 아이콘을 포함합니다. 구형 런처는 02_App_Icons 원본을 각 밀도에 맞게 내보내 사용합니다.

기존 설치 APK의 런처 아이콘은 이 리소스를 병합한 새 APK로 다시 빌드·설치해야 바뀝니다. 이번 패키지는 디자인 리소스이며 APK를 새로 빌드한 것은 아닙니다. 웹 화면 테마는 배포된 앱을 갱신하면 적용됩니다.
