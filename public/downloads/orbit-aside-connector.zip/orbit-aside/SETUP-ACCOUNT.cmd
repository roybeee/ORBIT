@echo off
chcp 65001 >nul
cd /d "%~dp0"
node bridge.mjs --setup
pause
